function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      
      <div className="bg-white w-80 p-6 border border-gray-300 rounded-md">
        
        <h1 className="text-4xl text-center mb-6 tracking-wide leading-loose font-serif text-black">
          Instagram
        </h1>

        <input
          type="text"
          placeholder="Phone number, username, or email"
          className="w-full mb-3 px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50 focus:outline-none"
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full mb-4 px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50 focus:outline-none"
        />

        <button
          className="w-full bg-[#0095F6] text-white py-2 rounded font-semibold hover:bg-blue-600"
        >
          Log In
        </button>

        <p className="text-center text-sm text-[#0095F6] mt-4 cursor-pointer">
          Forgot password?
        </p>

      </div>

    </div>
  )
}

export default App