import React from "react";

const LoginPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white border border-gray-300 p-8 w-80">
        <h1 className="text-3xl font-bold text-center mb-6">
          Instagram
        </h1>

        <input
          type="text"
          placeholder="Phone number, username, or email"
          className="w-full p-2 mb-3 border rounded text-sm"
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full p-2 mb-4 border rounded text-sm"
        />

        <button className="w-full bg-blue-500 text-white py-2 rounded">
          Log In
        </button>
      </div>
    </div>
  );
};

export default LoginPage;